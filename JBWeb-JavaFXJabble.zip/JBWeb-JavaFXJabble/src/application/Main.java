package application;
	
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;

import javax.swing.JOptionPane;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import vue.ModuleBoggle;
import vue.RectangleText;


public class Main extends Application {
	private int longueur = 1200;
	private int hauteur = 700;
	private int nombreDeModules = 5;
	private ModuleBoggle[] tousLesModules;
	private double registrePositions[][];
	private RectangleText rt = new RectangleText();
	private BorderPane root = new BorderPane();
	//private DicoCollectionsDeMotsSerializer dcdms = new DicoCollectionsDeMotsSerializer();
	private ArrayList<String> motsDejaTrouves = new ArrayList<String>();
	private Label lblcompteurMots = new Label(" 0 mot");
	private Label lblcompteurPoints = new Label(" 0 point");
	private Label lblcompteurChrono = new Label(" 00:00:00");
	private boolean modeTrouverMaxLettres = false;
	private boolean modeTrouverMaxMots = false;
	private int compteRebours = 120,nbMotsTrouves = 0,nbPoints = 0, nbMotsPossibles = 0, nbPointsPossibles = 0, tempsEcoule = 0;
	private int listeDeLettres[] = new int[27];
	private Timeline timeline;
	private boolean chronoEnMarche = false;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			Scene scene = new Scene(root,longueur,hauteur);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Combien de lettres ?");
			alert.setHeaderText("On peut jouer de 3 � 6 lettres... par d�faut, c'est 5.");
			alert.setContentText("Choisissez le nombre de lettres :");

			ButtonType buttonType3 = new ButtonType("3");
			ButtonType buttonType4 = new ButtonType("4");
			ButtonType buttonType5 = new ButtonType("5");
			ButtonType buttonType6 = new ButtonType("6");
			ButtonType buttonTypeCancel = new ButtonType("Annuler", ButtonData.CANCEL_CLOSE);

			alert.getButtonTypes().setAll(buttonType3, buttonType4, buttonType5,buttonType6, buttonTypeCancel);

			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == buttonType3){
				nombreDeModules = 3;
			} else if (result.get() == buttonType4) {
				nombreDeModules = 4;
			} else if (result.get() == buttonType5) {
				nombreDeModules = 5;
			} else if (result.get() == buttonType6) {
				nombreDeModules = 6;
			} else {
				nombreDeModules = 5;
			}
			
			alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Quel mode de jeu ?");
			alert.setHeaderText("Mode Max de lettres : vous devez trouver un mot avec toutes\n"
					+ "les lettres pour qu'une nouvelle �nigme apparaisse. Temps limit�.\n"
					+ "Mode Max de mots : vous devez trouver tous les mots possibles en vous\n"
					+ "servant de toutes ou une partie des lettres. Temps illimit�.\n"
					+ "(Par d�faut, c'est le Max de mots).");
			alert.setContentText("Choisissez votre mode :");

			ButtonType buttonMaxLettres = new ButtonType("Max de lettres");
			ButtonType buttonMaxMots = new ButtonType("Max de Mots");
			buttonTypeCancel = new ButtonType("Annuler", ButtonData.CANCEL_CLOSE);

			alert.getButtonTypes().setAll(buttonMaxLettres, buttonMaxMots, buttonTypeCancel);

			result = alert.showAndWait();
			if (result.get() == buttonMaxLettres){
				modeTrouverMaxLettres = true;
				modeTrouverMaxMots = false;
			} else if (result.get() == buttonMaxMots) {
				modeTrouverMaxLettres = false;
				modeTrouverMaxMots = true;
				String temps = "";
	        	int min =0;
				int h = 0;
				int sec = compteRebours;
				if (compteRebours>=3600) {
					h = compteRebours/3600;
					min = (compteRebours-(3600*h))/60;
					sec = compteRebours-((h*3600)+(min*60));
				}
				else if (sec>=60) {
					min = sec/60;
					sec = sec-(min*60);
				}
				temps = " "+((h<10)?("0"+h):(h))+":"+((min<10)?("0"+min):(min))+":"+((sec<10)?("0"+sec):(sec));
	        	lblcompteurChrono.setText(temps);
			} else {
				modeTrouverMaxLettres = false;
				modeTrouverMaxMots = true;
			}
			String title = "Jeu du Jabble avec "+nombreDeModules+" modules, mode ";
			if (modeTrouverMaxLettres){
				title+=" trouver les anagrammes complets, par JBWeb";
			} else if (modeTrouverMaxMots){
				title+=" trouver tous les anagrammes complets ou partiels, par J.BELIN";
			}
			primaryStage.setTitle(title);

			tousLesModules = new ModuleBoggle[nombreDeModules];
			registrePositions = new double[nombreDeModules][4];
			
			int decalagehorizontal = 0;
			int decalagevertical = 0;
			for (int i =0; i<nombreDeModules;i++){
				tousLesModules[i] = new ModuleBoggle(i,nombreDeModules,rangToChar(i+1),20+decalagehorizontal,60+decalagevertical);
				if ((i+1)%5==0){
					decalagevertical+=220;
				}
				if ((i+1)%5!=0){
					decalagehorizontal+=220;
				} else {
					decalagehorizontal=0;
				}
				root.getChildren().add(tousLesModules[i]);
				ajouteListenerChangementPosition(tousLesModules[i]);
			}
			motsDejaTrouves.clear();
			nbMotsTrouves=0;
			nbPoints=0;
			nouvelleEnigme();if (modeTrouverMaxMots){
				lanceChrono(false);
			    lblcompteurMots.setText(" 0 mot sur "+nbMotsPossibles);
			    lblcompteurPoints.setText(" 0 point sur "+nbPointsPossibles);
			    lblcompteurChrono.setText(" 00:00:00");
			} else if (modeTrouverMaxLettres){
				lanceChrono(true);
				chronoEnMarche = true;
			    lblcompteurMots.setText(" 0 mot");
			    lblcompteurPoints.setText(" 0 point");
			    String temps = "";
	        	int min =0;
				int h = 0;
				int sec = tempsEcoule;
				if (tempsEcoule>=3600) {
					h = tempsEcoule/3600;
					min = (tempsEcoule-(3600*h))/60;
					sec = tempsEcoule-((h*3600)+(min*60));
				}
				else if (sec>=60) {
					min = sec/60;
					sec = sec-(min*60);
				}
				temps = " "+((h<10)?("0"+h):(h))+":"+((min<10)?("0"+min):(min))+":"+((sec<10)?("0"+sec):(sec));
	        	lblcompteurChrono.setText(temps);
			}
			reactualisePositionsActuellesModules();
			alerteTousLesModulesPositionsInterdites(new ModuleBoggle(-1,nombreDeModules,'z',0,0));

			root.getChildren().add(rt);
			
			Button btnMelanger = new Button();
			btnMelanger.setText("Relancer le jeu");
			btnMelanger.setFont(new Font("LCD",20));
		    btnMelanger.setMinHeight(40.0);
		    btnMelanger.setMinWidth(250.0);
		    btnMelanger.setOnAction(new EventHandler<ActionEvent>() {
		        @Override
		        public void handle(ActionEvent event) {
					motsDejaTrouves.clear();
					nbMotsTrouves=0;
					nbPoints=0;
            		timeline.stop();
					nouvelleEnigme();
					if (modeTrouverMaxMots){
						lanceChrono(false);
					    lblcompteurMots.setText(" 0 mot sur "+nbMotsPossibles);
					    lblcompteurPoints.setText(" 0 point sur "+nbPointsPossibles);
					    lblcompteurChrono.setText(" 00:00:00");
					} else if (modeTrouverMaxLettres){
						lanceChrono(true);
						chronoEnMarche = true;
					    lblcompteurMots.setText(" 0 mot");
					    lblcompteurPoints.setText(" 0 point");
					    String temps = "";
			        	int min =0;
						int h = 0;
						int sec = tempsEcoule;
						if (tempsEcoule>=3600) {
							h = tempsEcoule/3600;
							min = (tempsEcoule-(3600*h))/60;
							sec = tempsEcoule-((h*3600)+(min*60));
						}
						else if (sec>=60) {
							min = sec/60;
							sec = sec-(min*60);
						}
						temps = " "+((h<10)?("0"+h):(h))+":"+((min<10)?("0"+min):(min))+":"+((sec<10)?("0"+sec):(sec));
			        	lblcompteurChrono.setText(temps);
					}	        	
		        }
		    });
		    btnMelanger.setDisable(false);
			
		    HBox vboxMelanger = new HBox();
		    vboxMelanger.getChildren().add(btnMelanger);

		    lblcompteurMots.setMinHeight(40.0);
		    lblcompteurMots.setMinWidth(250.0);
		    lblcompteurMots.setFont(new Font("LCD",30));
		    vboxMelanger.getChildren().add(lblcompteurMots);


		    lblcompteurPoints.setMinHeight(40.0);
		    lblcompteurPoints.setMinWidth(250.0);
		    lblcompteurPoints.setFont(new Font("LCD",30));
		    vboxMelanger.getChildren().add(lblcompteurPoints);

		    lblcompteurChrono.setMinHeight(40.0);
		    lblcompteurChrono.setMinWidth(150.0);
		    lblcompteurChrono.setFont(new Font("LCD",30));
		    vboxMelanger.getChildren().add(lblcompteurChrono);
		    
		    vboxMelanger.setTranslateX(10);
		    vboxMelanger.setTranslateY(10);
		    
		    root.getChildren().add(vboxMelanger);// on l'ajoute � notre groupe root
			
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public int nombreAleatoireEntre(int min, int max) {
		Random rand = new Random();
		int nombre = rand.nextInt(max - min + 1) + min;
		return nombre;
	}
	
	public void lanceChrono(boolean compteARebours){
		tempsEcoule = 0;
		if (compteARebours){
			tempsEcoule = compteRebours;
		}
		timeline = new Timeline(new KeyFrame(
	        Duration.millis(1000),
	        ae -> {
	    		if (compteARebours){
	    			tempsEcoule--;
	    		} else {
	    			tempsEcoule++;
	    		}
	        	String temps = "";
	        	int min =0;
				int h = 0;
				int sec = tempsEcoule;
				if (tempsEcoule>=3600) {
					h = tempsEcoule/3600;
					min = (tempsEcoule-(3600*h))/60;
					sec = tempsEcoule-((h*3600)+(min*60));
				}
				else if (sec>=60) {
					min = sec/60;
					sec = sec-(min*60);
				}
				temps = " "+((h<10)?("0"+h):(h))+":"+((min<10)?("0"+min):(min))+":"+((sec<10)?("0"+sec):(sec));
	        	lblcompteurChrono.setText(temps);
	    		if (tempsEcoule==0){
					chronoEnMarche = false;
	    			timeline.stop();
	    			for (int i =0; i<nombreDeModules;i++){
	    				tousLesModules[i].setVisible(false);
	    			}
	    			RectangleText rt2 = new RectangleText("Bravo, vous avez trouve "+nbMotsTrouves+" mot"+(nbMotsTrouves>1?"s":""),
	    					new Font("LCD",70.0),Color.BLACK,Color.WHITE,Color.BLACK);
					rt2.setTranslateX((longueur-rt2.getLargeur())/2);
	            	//rt2.setTranslateY((hauteur-rt2.getHauteur())/1.5d);
	            	rt2.setTranslateY(hauteur-rt2.getHauteur()-10);
	            	rt2.setOpacity(1.0); 
	            	rt2.setVisible(true);
					root.getChildren().add(rt2);
	            	FadeTransition ft2 = new FadeTransition(Duration.millis(6000), rt2);
	            	ft2.setFromValue(1.0);
	            	ft2.setToValue(0.0);
	            	ft2.play();
	            	ft2.setOnFinished(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent arg0) {
							motsDejaTrouves.clear();
							root.getChildren().remove(rt2);
							nbMotsTrouves=0;
							nbPoints=0;
						}
            		});
	    		}
	        }));
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}
	
	public void nouvelleEnigme(){
    	nbMotsPossibles = 0;
    	nbPointsPossibles = 0;
		String lemot = rechercheNouveauMot();
		System.out.println("Le mot � trouver est : "+lemot);
		char tableauChar[] = new char[lemot.length()];	
		int ordre[] = new int[lemot.length()];
		for (int i=0; i<lemot.length();i++){
			tableauChar[i] = lemot.charAt(i);
			ordre[i] = -1;
		}
		int rang = 0;
		do{
			int rangChoisi = nombreAleatoireEntre(0,lemot.length()-1);
			if (ordre[rangChoisi]==-1){
				ordre[rangChoisi]=rang;
				rang++;
			}
			
		} while (rang<lemot.length());
		int decalagehorizontal = 0;
		int decalagevertical = 0;
		for (int i =0; i<nombreDeModules;i++){
			tousLesModules[i].setVisible(true);
			tousLesModules[i].setPositionX(20+decalagehorizontal);
			tousLesModules[i].setPositionY(60+decalagevertical);
			tousLesModules[i].setTranslateX(20+decalagehorizontal);
			tousLesModules[i].setTranslateY(60+decalagevertical);
			tousLesModules[i].setLettre(tableauChar[ordre[i]]);
			tousLesModules[i].setIndiceModuleColleADroite(-1);
			tousLesModules[i].setIndiceModuleColleAGauche(-1);
			if ((i+1)%5==0){
				decalagevertical+=220;
			}
			if ((i+1)%5!=0){
				decalagehorizontal+=220;
			} else {
				decalagehorizontal=0;
			}
		}
	}
	
	public void reactualisePositionsActuellesModules(){
		for (int i =0; i<nombreDeModules;i++){
			registrePositions[i][0] = tousLesModules[i].getPositionX();
			registrePositions[i][1] = tousLesModules[i].getPositionY();
			registrePositions[i][2] = tousLesModules[i].getPositionX()+tousLesModules[i].getDimensionModule();
			registrePositions[i][3] = tousLesModules[i].getPositionY()+tousLesModules[i].getDimensionModule();
		}	
	}
	
	public void ajouteListenerChangementPosition(ModuleBoggle module){		
		module.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent event) {
				int moduleSignale = module.getIdentifiant();
				String motCompose = "";
				if (event.getPropertyName().equals("positionProvisoireCoinSuperieurGauche2D")){
					if (module.getIndiceModuleColleADroite()>-1){
						tousLesModules[module.getIndiceModuleColleADroite()].setIndiceModuleColleAGauche(-1);
						module.setIndiceModuleColleADroite(-1);
					}
					if (module.getIndiceModuleColleAGauche()>-1){
						tousLesModules[module.getIndiceModuleColleAGauche()].setIndiceModuleColleADroite(-1);
						module.setIndiceModuleColleAGauche(-1);
					}
	        		//System.out.println("le module n�"+module.getIdentifiant()+" bouge  : ses nouvelles coordonn�es sont X="+module.getPositionX()+" et Y="+module.getPositionY());				
				} else if (event.getPropertyName().equals("positionCoinSuperieurGauche2D")){
					if (module.getIndiceModuleColleADroite()>-1){
						tousLesModules[module.getIndiceModuleColleADroite()].setIndiceModuleColleAGauche(-1);
					}
					if (module.getIndiceModuleColleAGauche()>-1){
						tousLesModules[module.getIndiceModuleColleAGauche()].setIndiceModuleColleADroite(-1);
					}
					//System.out.println("le module n�"+moduleSignale+" a fini de bouger  : ses nouvelles coordonn�es sont X="+module.getPositionX()+" et Y="+module.getPositionY());
					//System.out.println("le module n�"+moduleSignale+" a, � gauche, le module n�"+module.getIndiceModuleColleAGauche()+" et � droite le n�"+module.getIndiceModuleColleADroite());	
				} else if (event.getPropertyName().equals("indiceModuleColleADroite")){
					if ((int)event.getOldValue()>-1){
						tousLesModules[(int)event.getOldValue()].setIndiceModuleColleAGauche(-1);
					}
					int moduleAttirant = module.getIndiceModuleColleADroite();
					tousLesModules[moduleAttirant].setIndiceModuleColleAGauche(moduleSignale);
					//System.out.println("Le module signal� n�"+moduleSignale+" vient de se coller � la gauche du module n�"+moduleAttirant);
					//System.out.println("le module signal� n�"+moduleSignale+" a, � gauche, le module n�"+module.getIndiceModuleColleAGauche()+" et � droite le n�"+module.getIndiceModuleColleADroite());
					//System.out.println("le module attirant n�"+moduleAttirant+" a, � gauche, le module n�"+tousLesModules[moduleAttirant].getIndiceModuleColleAGauche()+" et � droite le n�"+tousLesModules[moduleAttirant].getIndiceModuleColleADroite());
					
					boolean ilenresteapres = true;
					int suiteDesModules[] = new int[nombreDeModules];
					suiteDesModules[0] = module.getIdentifiant();
					suiteDesModules[1] = module.getIndiceModuleColleADroite();
					int rangModuleEtudie = 1;
					//Les modules s'encha�nent de la gauche vers la droite
					do{
						if (rangModuleEtudie==nombreDeModules){
							ilenresteapres = false;
						}
						else if (tousLesModules[suiteDesModules[rangModuleEtudie]].getIndiceModuleColleADroite()>-1){
							suiteDesModules[rangModuleEtudie+1] = tousLesModules[suiteDesModules[rangModuleEtudie]].getIndiceModuleColleADroite();
							rangModuleEtudie++;
						} else {
							ilenresteapres = false;
						}
					} while (ilenresteapres);
					for (int i=0;i<rangModuleEtudie+1;i++){
						motCompose += tousLesModules[suiteDesModules[i]].getLettre();
					}
					//System.out.println(motCompose);
					
					/*if (tousLesModules[moduleAttirant].getIndiceModuleColleADroite()>-1){
						int moduleDejaColle = tousLesModules[moduleAttirant].getIndiceModuleColleADroite();
						if (tousLesModules[moduleDejaColle].getIndiceModuleColleADroite()>-1){
							int moduleDejaColleBis = tousLesModules[moduleDejaColle].getIndiceModuleColleADroite();
							if (tousLesModules[moduleDejaColleBis].getIndiceModuleColleADroite()>-1){
								int moduleDejaColleTer = tousLesModules[moduleDejaColleBis].getIndiceModuleColleADroite();
								//System.out.println("Les modules n�"+moduleDejaColle+","+moduleDejaColleBis+" et "+moduleDejaColleTer+" �taient d�j� coll�s � la droite du module n�"+moduleAttirant);
								motCompose = tousLesModules[moduleSignale].getLettre()+""+tousLesModules[moduleAttirant].getLettre()+""+tousLesModules[moduleDejaColle].getLettre()
										+""+tousLesModules[moduleDejaColleBis].getLettre()+""+tousLesModules[moduleDejaColleTer].getLettre();
								//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
							} else {
							//System.out.println("Les modules n�"+moduleDejaColle+" et "+moduleDejaColleBis+" �taient d�j� coll�s � la droite du module n�"+moduleAttirant);
							motCompose = tousLesModules[moduleSignale].getLettre()+""+tousLesModules[moduleAttirant].getLettre()+""+tousLesModules[moduleDejaColle].getLettre()
									+""+tousLesModules[moduleDejaColleBis].getLettre();
							//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
							}
						} else {
						//System.out.println("Le module n�"+moduleDejaColle+" �tait d�j� coll� � la droite du module n�"+moduleAttirant);
						motCompose = (tousLesModules[moduleSignale].getLettre()+""+tousLesModules[moduleAttirant].getLettre()+""+tousLesModules[moduleDejaColle].getLettre());
						//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
						}
					} else {
						motCompose = (tousLesModules[moduleSignale].getLettre()+""+tousLesModules[moduleAttirant].getLettre());
						//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
					}*/
				} else if (event.getPropertyName().equals("indiceModuleColleAGauche")){
					if ((int)event.getOldValue()>-1){
						tousLesModules[(int)event.getOldValue()].setIndiceModuleColleADroite(-1);
					}
					int moduleAttirant = module.getIndiceModuleColleAGauche();
					tousLesModules[moduleAttirant].setIndiceModuleColleADroite(moduleSignale);
					
					boolean ilenresteapres = true;
					int suiteDesModules[] = new int[nombreDeModules];
					suiteDesModules[0] = module.getIdentifiant();
					suiteDesModules[1] = module.getIndiceModuleColleAGauche();
					int rangModuleEtudie = 1;
					//Les modules s'encha�nent de la droite vers la gauche : pour la lecture, il faudra faire � l'envers !
					do{
						if (rangModuleEtudie==nombreDeModules){
							ilenresteapres = false;
						}
						else if (tousLesModules[suiteDesModules[rangModuleEtudie]].getIndiceModuleColleAGauche()>-1){
							suiteDesModules[rangModuleEtudie+1] = tousLesModules[suiteDesModules[rangModuleEtudie]].getIndiceModuleColleAGauche();
							rangModuleEtudie++;
						} else {
							ilenresteapres = false;
						}
					} while (ilenresteapres);
					for (int i=rangModuleEtudie;i>=0;i--){
						motCompose += tousLesModules[suiteDesModules[i]].getLettre();
					}
					
					//System.out.println("Le module signal� n�"+moduleSignale+" vient de se coller � la droite du module n�"+moduleAttirant);
					//System.out.println("le module signal� n�"+moduleSignale+" a, � gauche, le module n�"+module.getIndiceModuleColleAGauche()+" et � droite le n�"+module.getIndiceModuleColleADroite());
					//System.out.println("le module attirant n�"+moduleAttirant+" a, � gauche, le module n�"+tousLesModules[moduleAttirant].getIndiceModuleColleAGauche()+" et � droite le n�"+tousLesModules[moduleAttirant].getIndiceModuleColleADroite());
					/*if (tousLesModules[moduleAttirant].getIndiceModuleColleAGauche()!=-1){
						int moduleDejaColle = tousLesModules[moduleAttirant].getIndiceModuleColleAGauche();
						if (tousLesModules[moduleDejaColle].getIndiceModuleColleAGauche()!=-1){
							int moduleDejaColleBis = tousLesModules[moduleDejaColle].getIndiceModuleColleAGauche();
							if (tousLesModules[moduleDejaColleBis].getIndiceModuleColleAGauche()!=-1){
								int moduleDejaColleTer = tousLesModules[moduleDejaColleBis].getIndiceModuleColleAGauche();
								//System.out.println("Les modules n�"+moduleDejaColleTer+","+moduleDejaColleBis+" et "+moduleDejaColle+" �taient d�j� coll�s � la gauche du module n�"+moduleAttirant);
								motCompose = tousLesModules[moduleDejaColleTer].getLettre()+""+tousLesModules[moduleDejaColleBis].getLettre()+""+tousLesModules[moduleDejaColle].getLettre()
										+""+tousLesModules[moduleAttirant].getLettre()+""+tousLesModules[moduleSignale].getLettre();
								//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
							} else {
							//System.out.println("Les modules n�"+moduleDejaColleBis+" et "+moduleDejaColle+" �taient d�j� coll�s � la gauche du module n�"+moduleAttirant);
							motCompose = tousLesModules[moduleDejaColleBis].getLettre()+""+tousLesModules[moduleDejaColle].getLettre()+""+tousLesModules[moduleAttirant].getLettre()
									+""+tousLesModules[moduleSignale].getLettre();
							//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
							}
						} else {
						//System.out.println("Le module n�"+moduleDejaColle+" �tait d�j� coll� � la gauche du module n�"+moduleAttirant);
						motCompose = (tousLesModules[moduleDejaColle].getLettre()+""+tousLesModules[moduleAttirant].getLettre()+""+tousLesModules[moduleSignale].getLettre());
						//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
						}
					} else {
						motCompose = (tousLesModules[moduleAttirant].getLettre()+""+tousLesModules[moduleSignale].getLettre());
						//System.out.println("Le mot compos� est donc \""+motCompose+"\".");
					}*/
				}
				reactualisePositionsActuellesModules();
				alerteTousLesModulesPositionsInterdites(module);
				if (!motCompose.equals("")) {
					if (modeTrouverMaxLettres){
						Color fond = Color.RED;
						boolean inedit = true;
						boolean toutesLesLettres = false;
						for (String str : motsDejaTrouves){
							if (str.equals(motCompose)){
								inedit = false;
							}
						}
						if ((verificateurExistenceMotParLectureTxt(motCompose))&&inedit&&(motCompose.length()==nombreDeModules)){
							toutesLesLettres = true;
							fond = Color.GREEN;
							motsDejaTrouves.clear();
						}
						else if ((verificateurExistenceMotParLectureTxt(motCompose))&&inedit){
							fond = Color.YELLOW;
							motsDejaTrouves.add(motCompose);
						} else if ((verificateurExistenceMotParLectureTxt(motCompose))&&!inedit){
							fond = Color.BLUE;
						} else {
							fond = Color.RED;
						}
						root.getChildren().remove(rt);
						rt = new RectangleText(motCompose,new Font("LCD",70.0),Color.BLACK,fond,Color.BLACK);
						rt.setTranslateX((longueur-rt.getLargeur())/2);
		            	//rt.setTranslateY((hauteur-rt.getHauteur())/2);
		            	rt.setTranslateY(10);
		            	rt.setOpacity(1.0); 
		            	rt.setVisible(true);
						root.getChildren().add(rt);
		            	FadeTransition ft = new FadeTransition(Duration.millis(1500), rt);
		            	ft.setFromValue(1.0);
		            	ft.setToValue(0.0);
		            	ft.play();
		            	if (toutesLesLettres){
							RectangleText rt2 = new RectangleText("Bravo, nouveau mot !",new Font("LCD",70.0),Color.BLACK,Color.WHITE,Color.BLACK);
							rt2.setTranslateX((longueur-rt2.getLargeur())/2);
			            	//rt2.setTranslateY((hauteur-rt2.getHauteur())/1.5d);
			            	rt2.setTranslateY(hauteur-rt2.getHauteur()-10);
			            	rt2.setOpacity(1.0); 
			            	rt2.setVisible(true);
							root.getChildren().add(rt2);
			            	FadeTransition ft2 = new FadeTransition(Duration.millis(2500), rt2);
			            	ft2.setFromValue(1.0);
			            	ft2.setToValue(0.0);
			            	ft2.play();
							nbMotsTrouves++;
						    lblcompteurMots.setText(" " +nbMotsTrouves+" mot"+(nbMotsTrouves>1?"s":""));
							nbPoints += motCompose.length();
						    lblcompteurPoints.setText(" " +nbPoints+" point"+(nbPoints>1?"s":""));
			            	ft2.setOnFinished(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent arg0) {
									root.getChildren().remove(rt2);
									if (chronoEnMarche){
										nouvelleEnigme();
									}
								}
		            		});
		            	}
					}
					else if (modeTrouverMaxMots){
						Color fond = Color.RED;
						boolean inedit = true;
						boolean toutesLesLettres = false;
						for (String str : motsDejaTrouves){
							if (str.equals(motCompose)){
								inedit = false;
							}
						}
						if ((verificateurExistenceMotParLectureTxt(motCompose))&&inedit){
							fond = Color.GREEN;
							motsDejaTrouves.add(motCompose);
							nbMotsTrouves++;
							nbPoints += motCompose.length();
						    lblcompteurMots.setText(" " +nbMotsTrouves+" mot"+(nbMotsTrouves>1?"s":"")+" sur "+nbMotsPossibles);
						    lblcompteurPoints.setText(" " +nbPoints+" point"+(nbPoints>1?"s":"")+" sur "+nbPointsPossibles);
						} else if ((verificateurExistenceMotParLectureTxt(motCompose))&&!inedit){
							fond = Color.BLUE;
						} else {
							fond = Color.RED;
						}
						root.getChildren().remove(rt);
						rt = new RectangleText(motCompose,new Font("LCD",70.0),Color.BLACK,fond,Color.BLACK);
						rt.setTranslateX((longueur-rt.getLargeur())/2);
		            	//rt.setTranslateY((hauteur-rt.getHauteur())/2);
		            	rt.setTranslateY(10);
		            	rt.setOpacity(1.0); 
		            	rt.setVisible(true);
						root.getChildren().add(rt);
		            	FadeTransition ft = new FadeTransition(Duration.millis(1500), rt);
		            	ft.setFromValue(1.0);
		            	ft.setToValue(0.0);
		            	ft.play();
		            	if (nbMotsTrouves>=nbMotsPossibles){
							RectangleText rt2 = new RectangleText("Bravo, nouvelle combinaison !",new Font("LCD",70.0),Color.BLACK,Color.WHITE,Color.BLACK);
							rt2.setTranslateX((longueur-rt2.getLargeur())/2);
			            	//rt2.setTranslateY((hauteur-rt2.getHauteur())/1.5d);
			            	rt2.setTranslateY(hauteur-rt2.getHauteur()-10);
			            	rt2.setOpacity(1.0); 
			            	rt2.setVisible(true);
							root.getChildren().add(rt2);
			            	FadeTransition ft2 = new FadeTransition(Duration.millis(2500), rt2);
			            	ft2.setFromValue(1.0);
			            	ft2.setToValue(0.0);
			            	ft2.play();
			            	ft2.setOnFinished(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent arg0) {
									motsDejaTrouves.clear();
									root.getChildren().remove(rt2);
									nbMotsTrouves=0;
									nbPoints=0;
				            		timeline.stop();
									nouvelleEnigme();
								    lblcompteurMots.setText(" " +nbMotsTrouves+" mot"+(nbMotsTrouves>1?"s":"")+" sur "+nbMotsPossibles);
								    lblcompteurPoints.setText(" " +nbPoints+" point"+(nbPoints>1?"s":"")+" sur "+nbPointsPossibles);
									lanceChrono(false);
								}
		            		});
		            	}
					}
				}
			}
		});
		
	}

	public char rangToChar(int rang){
		char lettre = '0';
		switch (rang){
		case 1 : {lettre = 'A';break;}
		case 2 : {lettre = 'B';break;}
		case 3 : {lettre = 'C';break;}
		case 4 : {lettre = 'D';break;}
		case 5 : {lettre = 'E';break;}
		case 6 : {lettre = 'F';break;}
		case 7 : {lettre = 'G';break;}
		case 8 : {lettre = 'H';break;}
		case 9 : {lettre = 'I';break;}
		case 10 : {lettre = 'J';break;}
		case 11 : {lettre = 'K';break;}
		case 12 : {lettre = 'L';break;}
		case 13 : {lettre = 'M';break;}
		case 14 : {lettre = 'N';break;}
		case 15 : {lettre = 'O';break;}
		case 16 : {lettre = 'P';break;}
		case 17 : {lettre = 'Q';break;}
		case 18 : {lettre = 'R';break;}
		case 19 : {lettre = 'S';break;}
		case 20 : {lettre = 'T';break;}
		case 21 : {lettre = 'U';break;}
		case 22 : {lettre = 'V';break;}
		case 23 : {lettre = 'W';break;}
		case 24 : {lettre = 'X';break;}
		case 25 : {lettre = 'Y';break;}
		case 26 : {lettre = 'Z';break;}
		}
		return lettre;
	}

	public int charToRang(char lettre){
		int rang = -1;
		switch (lettre){
		case 'A' : {rang = 1;break;}
		case 'B' : {rang = 2;break;}
		case 'C' : {rang = 3;break;}
		case 'D' : {rang = 4;break;}
		case 'E' : {rang = 5;break;}
		case 'F' : {rang = 6;break;}
		case 'G' : {rang = 7;break;}
		case 'H' : {rang = 8;break;}
		case 'I' : {rang = 9;break;}
		case 'J' : {rang = 10;break;}
		case 'K' : {rang = 11;break;}
		case 'L' : {rang = 12;break;}
		case 'M' : {rang = 13;break;}
		case 'N' : {rang = 14;break;}
		case 'O' : {rang = 15;break;}
		case 'P' : {rang = 16;break;}
		case 'Q' : {rang = 17;break;}
		case 'R' : {rang = 18;break;}
		case 'S' : {rang = 19;break;}
		case 'T' : {rang = 20;break;}
		case 'U' : {rang = 21;break;}
		case 'V' : {rang = 22;break;}
		case 'W' : {rang = 23;break;}
		case 'X' : {rang = 24;break;}
		case 'Y' : {rang = 25;break;}
		case 'Z' : {rang = 26;break;}
		}
		return rang;
	}

	public int chargeNombreLignes(String fichier){
		String str="";
		int count =0;
		if (new File(fichier).exists()){
			try {
				FileInputStream fis = new FileInputStream(fichier);//style "files/maclasse.txt"
				LineNumberReader l = new LineNumberReader(new BufferedReader(new InputStreamReader(fis)));
				while ((str=l.readLine())!=null)
					{
						count = l.getLineNumber();
					}
				fis.close();
				l.close();
			} catch (FileNotFoundException e) {
				System.out.println("Erreur de chargement depuis le fichier..."+fichier);
			} catch (IOException e) {
				System.out.println("Erreur de chargement depuis le fichier..."+fichier);
			}
		}
		return count;
	}
	
	public String rechercheNouveauMot(){
		String motTrouve = "";
		do {
			int nbLettres = nombreDeModules;
			char lettre = rangToChar(nombreAleatoireEntre(1,26));
			File fichier = new File("files/"+((nbLettres<10)?("0"+nbLettres):(nbLettres))+"-lettres/"
								+lettre+((nbLettres<10)?("0"+nbLettres):(nbLettres))+".txt");
			int nbLignes = chargeNombreLignes("files/"+((nbLettres<10)?("0"+nbLettres):(nbLettres))+"-lettres/"
								+lettre+((nbLettres<10)?("0"+nbLettres):(nbLettres))+".txt");
			if (fichier.exists()&&nbLignes>0)
			{
				String unmot = "";
				int carac=0;
				int rangMot = nombreAleatoireEntre(0,nbLignes);
				try {
					LineNumberReader fnr = new LineNumberReader(new FileReader(fichier));
					while ((carac = fnr.read()) != -1) {
						if (fnr.getLineNumber() == (rangMot + 1))
							break;
		
						else {
							if (fnr.getLineNumber() == rangMot) {
								unmot += (char) carac;
							}
						}
					}
					motTrouve = unmot.toUpperCase().trim();
					fnr.close();
				} catch (FileNotFoundException e) {
					JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier de mots !", "ERREUR",
							JOptionPane.ERROR_MESSAGE);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier de mots !", "ERREUR",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		} while (motTrouve.length()<=1);
		// R�initialisation des occurences des lettres
		for (int i = 0; i <= 26; i++) {
			listeDeLettres[i] = 0;
		}
		int nbDeLettres = motTrouve.length(); 
		// Comptage des occurences des lettres
		for (int i = 0; i < nbDeLettres; i++) {
			listeDeLettres[charToRang(motTrouve.charAt(i))]++;//
		}
		//System.out.println(afficheCodeMot());
		verificateurAnagrammesParLectureTxt();
		return motTrouve;
	}

	/*public String afficheCodeMot(){
		String str = "";
		for (int i=0;i<=26;i++){
			str+=listeDeLettres[i];
		}
		return str;
	}*/
	
	public void verificateurAnagrammesParLectureTxt(){
		//Recherche des mots depuis celui qui a le plus de lettres (this.nbDeLettres) jusqu'� 2 :	
		for (int i=nombreDeModules;i>=2;i--){
			for (int j=1;j<27;j++){
				if (listeDeLettres[j]>0){
					char lettre = rangToChar(j);
					int nbLignes = chargeNombreLignes("files/"+((i<10)?("0"+i):(i))+"-lettres/"
							+lettre+((i<10)?("0"+i):(i))+".txt");
					for (int k=0;k<nbLignes;k++)
					{
						int carac=0;
						String mot = "";
						File fichier = new File("files/"+((i<10)?("0"+i):(i))+"-lettres/"
								+lettre+((i<10)?("0"+i):(i))+".txt");
						if (fichier.exists()){
							try {
								LineNumberReader fnr = new LineNumberReader(new FileReader(fichier));
								while((carac = fnr.read()) != -1)
								{
									if(fnr.getLineNumber() == (k+1))
										break;	
									else
									{
										if(fnr.getLineNumber() == k)
										{
											mot += (char)carac;						
										}
									}
								}
								fnr.close();
							} catch (FileNotFoundException e) {
								JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier "+fichier.getName(), "ERREUR", JOptionPane.ERROR_MESSAGE);
							} catch (IOException e) {
								JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier "+fichier.getName(), "ERREUR", JOptionPane.ERROR_MESSAGE);
							}
							mot = mot.trim();
							//System.out.println(mot);
							if (testeMotAnagramme(mot)){
								//System.out.println("enregistr� :"+mot);
								nbMotsPossibles++;
								nbPointsPossibles+=mot.length();
							}
						}
					}
				}
			}		
		}
	}

	public boolean testeMotAnagramme(String aTester) {
		//System.out.println(afficheCodeMot());
		aTester = aTester.trim();
		boolean cEstUnAnagramme = true;
		// Le premier teste si c'est un anagramme pur = 0
		// Le deuxi�me teste si c'est un anagramme partiel (le mot contient
		// quelques lettres de la s�lection,
		// mais pas toutes, mais surtout pas en plus ! = nombre de lettres qui
		// diff�rent
		int listeLettres[] = new int[27];
		int nbLettres = aTester.length();
		// R�initialisation des occurences des lettres
		for (int i = 0; i <= 26; i++) { //i=1, on se fiche des "?"
			listeLettres[i] = 0;
		}

		// Comptage des occurences des lettres
		for (int i = 0; i < nbLettres; i++) {
			listeLettres[charToRang(aTester.charAt(i))]++;//
		}

		// V�rification des correspondances
		for (int i = 1; i <= 26; i++) {//i=1, on se fiche des "?"
			if (listeLettres[i] > listeDeLettres[i]) {
				// Ils ont une m�me lettre mais le mot � tester en a en trop
				cEstUnAnagramme = false;
				i = 27;// On arr�te la boucle !
			}
		}
		//System.out.println(aTester+" "+cEstUnAnagramme);
		return cEstUnAnagramme;
	}
	
	public boolean verificateurExistenceMotParLectureTxt(String mot){
		boolean motExiste = false;
		//Recherche des mots depuis celui qui a le plus de lettres (this.nbDeLettres) jusqu'� 2 :
		int nbLettres = mot.length();
		char lettre = mot.charAt(0);
		File fichier = new File("files/"+((nbLettres<10)?("0"+nbLettres):(nbLettres))+"-lettres/"
							+lettre+((nbLettres<10)?("0"+nbLettres):(nbLettres))+".txt");
		int nbLignes = chargeNombreLignes("files/"+((nbLettres<10)?("0"+nbLettres):(nbLettres))+"-lettres/"
							+lettre+((nbLettres<10)?("0"+nbLettres):(nbLettres))+".txt");
		String unmot = "";
		int carac=0;
		for (int i = 0; i < nbLignes; i++) {
			try {
				LineNumberReader fnr = new LineNumberReader(new FileReader(fichier));
				while ((carac = fnr.read()) != -1) {
					if (fnr.getLineNumber() == (i + 1))
						break;

					else {
						if (fnr.getLineNumber() == i) {
							unmot += (char) carac;
						}
					}
				}
				if ((unmot.toUpperCase().trim()).equals(mot.toUpperCase())){
					motExiste = true;
					break;
				}
				unmot = "";
				fnr.close();
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier de mots !", "ERREUR",
						JOptionPane.ERROR_MESSAGE);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier de mots !", "ERREUR",
						JOptionPane.ERROR_MESSAGE);
			}
		}
		return motExiste;
	}
	
	public void alerteTousLesModulesPositionsInterdites(ModuleBoggle modulequibouge){
		for (int i =0; i<nombreDeModules;i++){
			if (modulequibouge.getIdentifiant()!=i){
				tousLesModules[i].setRegistrePositionsInterdites(registrePositions);
			}
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}

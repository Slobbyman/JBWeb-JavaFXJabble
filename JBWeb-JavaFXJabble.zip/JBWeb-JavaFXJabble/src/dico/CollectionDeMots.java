package dico;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class CollectionDeMots implements Serializable{
	private char initiale = 'a';
	private int nombreDeLettres = 0;
	private ArrayList<String> listeMots = new ArrayList<String>();
	private int nombreDeMots = 0;
	
	public CollectionDeMots(){
	}
	
	public CollectionDeMots(char pinitiale,int pnblettres){
		this.initiale = pinitiale;
		this.nombreDeLettres = pnblettres;
	}
	
	public void ajouteMot(String mot){
		this.listeMots.add(mot);
	}
  
    public void sauvegardeTexte(){
    	new File("files/"+this.nombreDeLettres+"-lettres").mkdir();
    	File file = new File("files/"+this.nombreDeLettres+"-lettres/"+this.initiale+".txt");
    	FileWriter fw;
		 try {
			 //Cr�ation de l'objet
			 fw = new FileWriter(file,false);//true permet de dire qu'on rajoute � la fin
			 //String str = "";
			 for (int i=0;i<this.listeMots.size();i++){
				 fw.write(this.listeMots.get(i));
				 fw.write("\n");
			 }
			 //On �crit la cha�ne
			 //fw.write(str);
			 //On ferme le flux
			 fw.close();
			 System.out.print("Mots commen�ant par "+this.initiale+" et de "+this.nombreDeLettres+" lettres fini...");
		 } catch (FileNotFoundException e) {
			 e.printStackTrace();
		 } catch (IOException e) {
			 e.printStackTrace();
		 }
    }

	public char getInitiale() {
		return initiale;
	}

	public int getNombreDeLettres() {
		return nombreDeLettres;
	}

	public ArrayList<String> getListeMots() {
		return listeMots;
	}

	public int getNombreDeMots() {
		return this.listeMots.size();
	}

	public void setInitiale(char initiale) {
		this.initiale = initiale;
	}

	public void setNombreDeLettres(int nombreDeLettres) {
		this.nombreDeLettres = nombreDeLettres;
	}

	public void setListeMots(ArrayList<String> listeMots) {
		this.listeMots = listeMots;
	}
}
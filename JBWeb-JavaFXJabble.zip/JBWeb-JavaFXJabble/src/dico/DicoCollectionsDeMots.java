package dico;

import java.io.Serializable;
import java.util.ArrayList;

public class DicoCollectionsDeMots implements Serializable {

	private ArrayList<CollectionDeMots> toutesLesCollections = new ArrayList<CollectionDeMots>();
	
	public DicoCollectionsDeMots(){
	}
	
	public DicoCollectionsDeMots(ArrayList<CollectionDeMots> desCollections){
		toutesLesCollections = desCollections;
	}

	public ArrayList<CollectionDeMots> getToutesLesCollections() {
		return toutesLesCollections;
	}

	public void setToutesLesCollections(ArrayList<CollectionDeMots> toutesLesCollections) {
		this.toutesLesCollections = toutesLesCollections;
	}
	
}

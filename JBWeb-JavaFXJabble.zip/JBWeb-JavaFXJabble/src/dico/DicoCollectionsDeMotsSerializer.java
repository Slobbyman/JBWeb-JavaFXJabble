package dico;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.swing.JOptionPane;

public class DicoCollectionsDeMotsSerializer implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2334307548915921746L;
	private DicoCollectionsDeMots dcdm = new DicoCollectionsDeMots();
	
	public void setDicoCollectionsDeMots(DicoCollectionsDeMots pod){
		dcdm = pod;
	}

	public DicoCollectionsDeMotsSerializer() {
		try {
			File file = new File("files/DicoFran�ais.dic");
			if (file.length() > 0) {
				ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));

				dcdm = (DicoCollectionsDeMots) ois.readObject();
				ois.close();
			} else {
				dcdm = new DicoCollectionsDeMots();
			}

		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Pas de fichier de sauvegarde trouv� :\ncr�ation d'un nouveau fichier : \nfiles/GrilleTrioActuelle.3io" + e.getCause() + "\n",
					"ERREUR", JOptionPane.ERROR_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier (IO Exception) !\n"+e.getCause() + "\n",
					"ERREUR", JOptionPane.ERROR_MESSAGE);
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier (Class not found) !\n" +e.getCause() + "\n",
					"ERREUR", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public DicoCollectionsDeMots getDicoCollectionsDeMots(){
		return this.dcdm;
	}

	public void serialize() {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(
					new BufferedOutputStream(new FileOutputStream(new File("files/DicoFran�ais.dic"))));
			oos.writeObject(dcdm);
			oos.close();

		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Erreur d'enregistrement1 dans le fichier !" + e.getMessage(), "ERREUR",
					JOptionPane.ERROR_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Erreur d'enregistrement dans le fichier !" + e.getMessage(), "ERREUR",
					JOptionPane.ERROR_MESSAGE);
		}
	}

}
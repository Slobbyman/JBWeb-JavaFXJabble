package dico;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class VerificateurAnagrammes {
	String lettresATester = "";
	int nbDeLettres = 0;
	int listeDeLettres[] = new int[26]; //compte le nombre d'occurences de chaque lettre de l'alphabet :
	//Ex : array se code 20000000000000000200000010
	ArrayList<String> solutions = new ArrayList<String>();
	boolean anagrammesPurs = false;
	private DicoCollectionsDeMotsSerializer dcdms = new DicoCollectionsDeMotsSerializer();
	
	public VerificateurAnagrammes(){
		
	}

	public char rangToChar(int rang){
		char lettre = '0';
		switch (rang){
		case 1 : {lettre = 'A';break;}
		case 2 : {lettre = 'B';break;}
		case 3 : {lettre = 'C';break;}
		case 4 : {lettre = 'D';break;}
		case 5 : {lettre = 'E';break;}
		case 6 : {lettre = 'F';break;}
		case 7 : {lettre = 'G';break;}
		case 8 : {lettre = 'H';break;}
		case 9 : {lettre = 'I';break;}
		case 10 : {lettre = 'J';break;}
		case 11 : {lettre = 'K';break;}
		case 12 : {lettre = 'L';break;}
		case 13 : {lettre = 'M';break;}
		case 14 : {lettre = 'N';break;}
		case 15 : {lettre = 'O';break;}
		case 16 : {lettre = 'P';break;}
		case 17 : {lettre = 'Q';break;}
		case 18 : {lettre = 'R';break;}
		case 19 : {lettre = 'S';break;}
		case 20 : {lettre = 'T';break;}
		case 21 : {lettre = 'U';break;}
		case 22 : {lettre = 'V';break;}
		case 23 : {lettre = 'W';break;}
		case 24 : {lettre = 'X';break;}
		case 25 : {lettre = 'Y';break;}
		case 26 : {lettre = 'Z';break;}
		}
		return lettre;
	}

	public int charToRang(char lettre){
		int rang = -1;
		switch (lettre){
		case 'A' : {rang = 1;break;}
		case 'B' : {rang = 2;break;}
		case 'C' : {rang = 3;break;}
		case 'D' : {rang = 4;break;}
		case 'E' : {rang = 5;break;}
		case 'F' : {rang = 6;break;}
		case 'G' : {rang = 7;break;}
		case 'H' : {rang = 8;break;}
		case 'I' : {rang = 9;break;}
		case 'J' : {rang = 10;break;}
		case 'K' : {rang = 11;break;}
		case 'L' : {rang = 12;break;}
		case 'M' : {rang = 13;break;}
		case 'N' : {rang = 14;break;}
		case 'O' : {rang = 15;break;}
		case 'P' : {rang = 16;break;}
		case 'Q' : {rang = 17;break;}
		case 'R' : {rang = 18;break;}
		case 'S' : {rang = 19;break;}
		case 'T' : {rang = 20;break;}
		case 'U' : {rang = 21;break;}
		case 'V' : {rang = 22;break;}
		case 'W' : {rang = 23;break;}
		case 'X' : {rang = 24;break;}
		case 'Y' : {rang = 25;break;}
		case 'Z' : {rang = 26;break;}
		}
		return rang;
	}
	
	

	public VerificateurAnagrammes(String plettresATester,boolean purete){
		this.anagrammesPurs = purete;
		//R�initialisation des occurences des lettres
		for (int i=0;i<26;i++){
			listeDeLettres[i] = 0;
		}
		plettresATester = (plettresATester.trim()).toUpperCase();//En majuscules, sans espaces, sauts de ligne...
		this.lettresATester = plettresATester;
		this.nbDeLettres = plettresATester.length();

		//Comptage des occurences des lettres
		for (int i=0;i<this.nbDeLettres;i++){
			listeDeLettres[charToRang(plettresATester.charAt(i))-1]++;//-1 car dans un tableau, la case 1 est de rang 0...
		}

		long tempsDepart = System.currentTimeMillis();
		
		//verificateurAnagrammesParLectureTxt();
		verificateurAnagrammesParSerializer();
		
		//Affichage des r�sultats :
		if (this.solutions.isEmpty()){
			System.out.println("Aucune solution trouv�e !");
		}
		else {
			for (String solution : this.solutions){
				System.out.println(solution);
			}
		}
		long tempsFin = System.currentTimeMillis();
		long duree = (tempsFin - tempsDepart);
		System.out.println("\nOp�ration effectu�e en " + duree + "ms.");
	}
	
	public void verificateurAnagrammesParLectureTxt(){
		//Recherche des mots depuis celui qui a le plus de lettres (this.nbDeLettres) jusqu'� 2 :
		for (int i=this.nbDeLettres;i>=2;i--){
			for (int j=0;j<26;j++){
				if (listeDeLettres[j]>0){
					char lettre = rangToChar(j+1);
					int nbLignes = chargeNombreLignes("files/"+((i<10)?("0"+i):(i))+"-lettres/"
							+lettre+((i<10)?("0"+i):(i))+".txt");
					for (int k=0;k<nbLignes;k++)
					{
						int carac=0;
						String mot = "";
						try {
							LineNumberReader fnr = new LineNumberReader(new FileReader(new File("files/"+((i<10)?("0"+i):(i))+"-lettres/"
									+lettre+((i<10)?("0"+i):(i))+".txt")));
							while((carac = fnr.read()) != -1)
							{
								if(fnr.getLineNumber() == (k+1))
									break;	
								else
								{
									if(fnr.getLineNumber() == k)
									{
										mot += (char)carac;						
									}
								}
							}
						} catch (FileNotFoundException e) {
							JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier...", "ERREUR", JOptionPane.ERROR_MESSAGE);
						} catch (IOException e) {
							JOptionPane.showMessageDialog(null, "Erreur de chargement depuis le fichier...", "ERREUR", JOptionPane.ERROR_MESSAGE);
						}
						mot = mot.trim();
						if (this.anagrammesPurs){
							if (testeMotAnagramme(mot)[0]){
								solutions.add(mot);
							}
						} else {
							if (testeMotAnagramme(mot)[1]){
								solutions.add(mot);
							}			
						}
					}
				}
			}		
		}
	}
	
	public int getRangCollection(char init, int nbLettres){
		int rang = -1;
		for (int i=0;i<dcdms.getDicoCollectionsDeMots().getToutesLesCollections().size();i++){
			if ((dcdms.getDicoCollectionsDeMots().getToutesLesCollections().get(i).getInitiale()==init)&&
					(dcdms.getDicoCollectionsDeMots().getToutesLesCollections().get(i).getNombreDeLettres()==nbLettres)){
				rang=i;
			}
		}
		return rang;
	}

	public boolean verificateurAnagrammesParSerializer(){
		boolean trouve = false;
		//Recherche des mots depuis celui qui a le plus de lettres (this.nbDeLettres) jusqu'� 2 :
		for (int nbLettresActuel=this.nbDeLettres;nbLettresActuel>=2;nbLettresActuel--){
			for (int j=0;j<26;j++){
				if (listeDeLettres[j]>0){
					char lettre = rangToChar(j+1);
					int rangCollection = getRangCollection(lettre,nbLettresActuel);
					if (rangCollection>=0){
						int nbMotsCollectionActuelle = dcdms.getDicoCollectionsDeMots().getToutesLesCollections().get(rangCollection).getNombreDeMots();
						for (int rangMotDansLaCollection=0;rangMotDansLaCollection<nbMotsCollectionActuelle;rangMotDansLaCollection++)
						{
							String mot = dcdms.getDicoCollectionsDeMots().getToutesLesCollections().get(rangCollection).getListeMots().get(rangMotDansLaCollection);
							mot = mot.trim();
							if (this.anagrammesPurs){
								if (testeMotAnagramme(mot)[0]){
									solutions.add(mot);
									trouve = true;
								}
							} else {
								if (testeMotAnagramme(mot)[1]){
									solutions.add(mot);
									trouve = true;
								}			
							}
						}
					}
				}
			}		
		}
		return trouve;
	}
	
	public boolean[] testeMotAnagramme(String aTester){
		aTester = aTester.trim();
		boolean cEstUnAnagramme[] = {true,true};
		// Le premier teste si c'est un anagramme pur = 0
		// Le deuxi�me teste si c'est un anagramme partiel (le mot contient quelques lettres de la s�lection,
		// mais pas toutes, mais surtout pas en plus ! = nombre de lettres qui diff�rent
		int listeLettres[] = new int[26];
		int nbLettres = aTester.length();
		//R�initialisation des occurences des lettres
		for (int i=0;i<26;i++){
			listeLettres[i] = 0;
		}

		//Comptage des occurences des lettres
		for (int i=0;i<nbLettres;i++){
			listeLettres[charToRang(aTester.charAt(i))-1]++;//-1 car dans un tableau, la case 1 est de rang 0...
		}
		
		//V�rification des correspondances
		for (int i=0; i<26; i++){
			if ((listeLettres[i]!=0)&&(listeDeLettres[i]!=0)){ 
				if (listeLettres[i]>listeDeLettres[i]){
					//Ils ont une m�me lettre mais le mot � tester en a en trop
					cEstUnAnagramme[0] = false; //Ce n'est pas un anagramme pur !
					cEstUnAnagramme[1] = false; //Ce n'est pas un anagramme du tout !
					i=26;//On arr�te la boucle !
				} else if (listeLettres[i]<listeDeLettres[i]){
					//Ils ont une m�me lettre mais le mot � tester en a moins
					cEstUnAnagramme[0] = false; //Ce n'est pas un anagramme pur !
				}
			} else if ((listeLettres[i]==0)&&(listeDeLettres[i]!=0)){
				//Le mot � tester n'a pas cette lettre !
				cEstUnAnagramme[0] = false; //Ce n'est pas un anagramme pur !		
			} else if ((listeLettres[i]!=0)&&(listeDeLettres[i]==0)){
				//Le mot � tester a une lettre en trop
				cEstUnAnagramme[0] = false; //Ce n'est pas un anagramme pur !
				cEstUnAnagramme[1] = false; //Ce n'est pas un anagramme du tout !
				i=26;//On arr�te la boucle !
			}
		}
		return cEstUnAnagramme;
	}

	public int chargeNombreLignes(String fichier){
		String str="";
		int count =0;
		try {
			FileInputStream fis = new FileInputStream(fichier);//style "files/maclasse.txt"
			LineNumberReader l = new LineNumberReader(new BufferedReader(new InputStreamReader(fis)));
			while ((str=l.readLine())!=null)
				{
					count = l.getLineNumber();
				}
			fis.close();
			l.close();
		} catch (FileNotFoundException e) {
			System.out.println("Erreur de chargement depuis le fichier...");
		} catch (IOException e) {
			System.out.println("Erreur de chargement depuis le fichier...");
		}
		return count;
	}

	public static void main(String[] args) {
		VerificateurAnagrammes va = new VerificateurAnagrammes("kjdhgsjhdhuiiao",false);

	}

}

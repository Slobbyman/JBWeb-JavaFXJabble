package vue;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.sun.javafx.tk.FontLoader;
import com.sun.javafx.tk.Toolkit;

import javafx.event.EventHandler;
import javafx.geometry.Point2D;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ModuleBoggle extends Parent {
	private char lettre = 'a';
	private int identifiant = 0;
	private double positionX = 0d;
	private double positionY = 0d;
	//private double positionPrecedenteX = 0d;
	//private double positionPrecedenteY = 0d;
	private int dimensionModule = 200;
	// variables for storing initial position before drag of card
	private double initX;
	private double initY;
	private Point2D dragDistances2D;
	private Point2D positionSouris2D;
	private Point2D positionProvisoireCoinSuperieurGauche2D;
	private Point2D positionCoinSuperieurGauche2D;
	private double registrePositionsInterdites[][];// = new double[5][4];
	private double toleranceAimantationX = 50d;
	private double toleranceAimantationY = 80d;
	private int indiceModuleColleAGauche = -1;
	private int indiceModuleColleADroite = -1;
	private int nombreTotalModules = 5;
	PropertyChangeSupport changeSupport;
	Text txtgraphic;

	public ModuleBoggle() {

	}

	public ModuleBoggle(int id, int nombreModules, char plettre, int x, int y) {
		this.changeSupport = new PropertyChangeSupport(this);
		this.identifiant = id;
		this.nombreTotalModules = nombreModules;
		registrePositionsInterdites = new double[nombreTotalModules][4];
		// cr�ation du fond du module
		ImageView fondModule = new ImageView(new Image(ModuleBoggle.class.getResourceAsStream("images/Jabble.png")));
		/*
		 * fondModule.setFitHeight(dimensionModule);
		 * fondModule.setPreserveRatio(true);
		 */
		this.getChildren().add(fondModule);
		this.lettre = ((String.valueOf(plettre)).toUpperCase()).charAt(0);
		this.positionX = x;
		this.positionY = y;

		FontLoader fontLoader = Toolkit.getToolkit().getFontLoader();

		//int fontSize = 110;//Pour Arial
		int fontSize = 110;
		Font fontModule = Font.font("Blobb",fontSize);
		float longueurTextPixels = fontLoader.computeStringWidth(String.valueOf(lettre), fontModule);

		txtgraphic = new Text(String.valueOf(lettre));
		// txtgraphic.setY(140);
		// txtgraphic.setX(65);
		txtgraphic.setFont(fontModule);
		txtgraphic.setFill(Color.BLACK);
		//txtgraphic.setTranslateX((200 - longueurTextPixels) / 2);//Pour Arial
		txtgraphic.setTranslateX(10+(200 - longueurTextPixels) / 2);
		//txtgraphic.setTranslateY(77 + ((fontSize) / 2)); //Pour Arial
		txtgraphic.setTranslateY(80 + ((fontSize) / 2));
		// txtgraphic.setTranslateY(0);
		this.getChildren().add(txtgraphic);
		this.setTranslateX(x);
		this.setTranslateY(y);

		// add a mouse listeners
		this.setOnMouseClicked(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				// the event will be passed only to the circle which is on front
				me.consume(); // ????????????
			}
		});

		this.setOnMouseEntered(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				setCursor(Cursor.HAND);
			}
		});

		this.setOnMouseExited(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				setCursor(Cursor.DEFAULT);
			}
		});

		this.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				initX = positionX;
				initY = positionY;
				positionCoinSuperieurGauche2D = new Point2D(positionX,positionY);
				positionProvisoireCoinSuperieurGauche2D = new Point2D(positionX,positionY);
				dragDistances2D = new Point2D(me.getSceneX(), me.getSceneY());
			}
		});

		this.setOnMouseDragged(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				toFront();
				double dragX = me.getSceneX() - dragDistances2D.getX();
				double dragY = me.getSceneY() - dragDistances2D.getY();
				// calculate new position of the module
				double newXPosition = initX + dragX;
				double newYPosition = initY + dragY;
				// translate to this position
				/*if ((newXPosition >= 0) && (newXPosition <= getScene().getWidth() - dimensionModule)) {
					setPositionX((int) newXPosition);
				}
				if ((newYPosition >= 0) && (newYPosition <= getScene().getHeight() - dimensionModule)) {
					setPositionY((int) newYPosition);
				}*/
				if ((onPeutBougerXY(newXPosition,newYPosition))[0]){
					setPositionX((int) newXPosition);
				}
				if ((onPeutBougerXY(newXPosition,newYPosition))[1]){
					setPositionY((int) newYPosition);
				}
				setTranslateX(positionX);// positionnement du module
				setTranslateY(positionY);

				Point2D anciennesCoordonnees = positionProvisoireCoinSuperieurGauche2D;
				positionProvisoireCoinSuperieurGauche2D = new Point2D(positionX,positionY);
				changeSupport.firePropertyChange("positionProvisoireCoinSuperieurGauche2D", anciennesCoordonnees, positionProvisoireCoinSuperieurGauche2D);
			}
		});

		this.setOnMouseReleased(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				if (verifAimantation()){
					setTranslateX(positionX);// positionnement du module
					setTranslateY(positionY);
				} else {
					positionSouris2D = new Point2D(me.getSceneX(), me.getSceneY());
					Point2D anciennesCoordonnees = positionCoinSuperieurGauche2D;
					positionCoinSuperieurGauche2D = new Point2D(positionX,positionY);
					changeSupport.firePropertyChange("positionCoinSuperieurGauche2D", anciennesCoordonnees, positionCoinSuperieurGauche2D);
				}
			}
		});
	}
	
	public boolean verifAimantation(){
		boolean aEteAimante = false;
		for (int i=0;i<nombreTotalModules;i++){
			if (i!=this.identifiant){
				if ((((registrePositionsInterdites[i][0]-(positionX+dimensionModule))<toleranceAimantationX)&&((registrePositionsInterdites[i][0]-(positionX+dimensionModule))>=0))
						||((((positionX+dimensionModule)-registrePositionsInterdites[i][0])<toleranceAimantationX)&&(((positionX+dimensionModule)-registrePositionsInterdites[i][0])>=0))){
					if (((((positionY+dimensionModule)-registrePositionsInterdites[i][3])<toleranceAimantationY)&&(((positionY+dimensionModule)-registrePositionsInterdites[i][3])>=0))
							||(((registrePositionsInterdites[i][1]-positionY)<toleranceAimantationY)&&((registrePositionsInterdites[i][1]-positionY)>=0))){
						setPositionX((int) registrePositionsInterdites[i][0]-dimensionModule-1);
						setPositionY((int) registrePositionsInterdites[i][1]);
						//On annonce que le module vient de se coller au module i par la gauche, donc il a un module � sa droite !
						int anciennevaleur = indiceModuleColleADroite;
						indiceModuleColleADroite = i;
						changeSupport.firePropertyChange("indiceModuleColleADroite", anciennevaleur, indiceModuleColleADroite);
						aEteAimante = true;
						i=5;//on sort de la boucle
					}
				} else if ((((positionX-registrePositionsInterdites[i][2])<toleranceAimantationX)&&((positionX-registrePositionsInterdites[i][2])>=0))
						||(((registrePositionsInterdites[i][2]-positionX)<toleranceAimantationX)&&((registrePositionsInterdites[i][2]-positionX)>=0))){
					if (((((positionY+dimensionModule)-registrePositionsInterdites[i][3])<toleranceAimantationY)&&(((positionY+dimensionModule)-registrePositionsInterdites[i][3])>=0))
							||(((registrePositionsInterdites[i][1]-positionY)<toleranceAimantationY)&&((registrePositionsInterdites[i][1]-positionY)>=0))){
						setPositionX((int) registrePositionsInterdites[i][2]+1);
						setPositionY((int) registrePositionsInterdites[i][1]);
						//On annonce que le module vient de se coller au module i par la droite, donc il a un module � sa gauche !
						int anciennevaleur = indiceModuleColleAGauche;
						indiceModuleColleAGauche = i;
						changeSupport.firePropertyChange("indiceModuleColleAGauche", anciennevaleur, indiceModuleColleAGauche);
						aEteAimante = true;
						i=5;//on sort de la boucle
					}
				}
			}
		}
		return aEteAimante;
	}
	
	public boolean[] onPeutBougerXY(double newX,double newY){
		boolean onpeutbouger[] = {true,true};
		
		//Les X par rapport au bord
		if ((newX >= 0) && (newX <= getScene().getWidth() - dimensionModule)) {
			//OK
		} else {
			onpeutbouger[0] = false;
		}

		//Les Y par rapport au bord
		if ((newY >= 0) && (newY <= getScene().getHeight() - dimensionModule)) {
			//OK
		} else {
			onpeutbouger[1] = false;
		}
		
		/*
		for (int i=0;i<5;i++){
			if (i!=this.identifiant){
				//Les X
				if (newX+dimensionModule<registrePositionsInterdites[i][0]){
					//OK
				} else if (newX>registrePositionsInterdites[i][2]){
					//OK
				} else {
					if (newY>registrePositionsInterdites[i][3]){
						//OK
					} else if (newY+dimensionModule<registrePositionsInterdites[i][1]){
						//OK
					} else {
						//onpeutbouger[0] = false;
						onpeutbouger[1] = false;
					}
				}
				
				//Les Y
				if (newY+dimensionModule<registrePositionsInterdites[i][1]){
					//OK
				} else if (newY>registrePositionsInterdites[i][3]){
					//OK
				} else {
					if (newY>registrePositionsInterdites[i][2]){
						//OK
					} else if (newY+dimensionModule<registrePositionsInterdites[i][0]){
						//OK
					} else {
						onpeutbouger[0] = false;
						//onpeutbouger[1] = false;
					}
				}
			}
		}
		*/	
		return onpeutbouger;
	}

	public char getLettre() {
		return lettre;
	}

	public int getIdentifiant() {
		return identifiant;
	}

	public double getPositionX() {
		return positionX;
	}

	public double getPositionY() {
		return positionY;
	}

	public int getDimensionModule() {
		return dimensionModule;
	}

	public double getInitX() {
		return initX;
	}

	public double getInitY() {
		return initY;
	}

	public Point2D getDragDistances2D() {
		return dragDistances2D;
	}

	public Point2D getPositionSouris2D() {
		return positionSouris2D;
	}

	public void setLettre(char lettre) {
		this.lettre = lettre;
		txtgraphic.setText(String.valueOf(lettre));
		FontLoader fontLoader = Toolkit.getToolkit().getFontLoader();
		int fontSize = 110;
		Font fontModule = new Font("Arial", fontSize);
		float longueurTextPixels = fontLoader.computeStringWidth(String.valueOf(lettre), fontModule);
		txtgraphic.setTranslateX(10+(200 - longueurTextPixels) / 2);
	}

	public void setIdentifiant(int identifiant) {
		this.identifiant = identifiant;
	}

	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}

	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}

	public void setDimensionModule(int dimensionModule) {
		this.dimensionModule = dimensionModule;
	}

	public void setInitX(double initX) {
		this.initX = initX;
	}

	public void setInitY(double initY) {
		this.initY = initY;
	}

	public void setDragDistances2D(Point2D dragDistances2D) {
		this.dragDistances2D = dragDistances2D;
	}

	public void setPositionSouris2D(Point2D positionSouris2D) {
		this.positionSouris2D = positionSouris2D;
	}

	public synchronized void addPropertyChangeListener(PropertyChangeListener listener) {
		changeSupport.addPropertyChangeListener(listener);
	}

	public synchronized void removePropertyChangeListener(PropertyChangeListener listener) {
		changeSupport.removePropertyChangeListener(listener);
	}

	public Point2D getPositionProvisoireCoinSuperieurGauche2D() {
		return positionProvisoireCoinSuperieurGauche2D;
	}

	public Point2D getPositionCoinSuperieurGauche2D() {
		return positionCoinSuperieurGauche2D;
	}

	public double[][] getRegistrePositionsInterdites() {
		return registrePositionsInterdites;
	}

	public void setPositionX(double positionX) {
		this.positionX = positionX;
	}

	public void setPositionY(double positionY) {
		this.positionY = positionY;
	}

	public void setPositionProvisoireCoinSuperieurGauche2D(Point2D positionProvisoireCoinSuperieurGauche2D) {
		this.positionProvisoireCoinSuperieurGauche2D = positionProvisoireCoinSuperieurGauche2D;
	}

	public void setPositionCoinSuperieurGauche2D(Point2D positionCoinSuperieurGauche2D) {
		this.positionCoinSuperieurGauche2D = positionCoinSuperieurGauche2D;
	}

	public void setRegistrePositionsInterdites(double[][] registrePositionsInterdites) {
		this.registrePositionsInterdites = registrePositionsInterdites;
	}

	public double getToleranceAimantationX() {
		return toleranceAimantationX;
	}

	public double getToleranceAimantationY() {
		return toleranceAimantationY;
	}

	public int getIndiceModuleColleAGauche() {
		return indiceModuleColleAGauche;
	}

	public int getIndiceModuleColleADroite() {
		return indiceModuleColleADroite;
	}

	public void setToleranceAimantationX(double toleranceAimantationX) {
		this.toleranceAimantationX = toleranceAimantationX;
	}

	public void setToleranceAimantationY(double toleranceAimantationY) {
		this.toleranceAimantationY = toleranceAimantationY;
	}

	public void setIndiceModuleColleAGauche(int indiceModuleColleAGauche) {
		this.indiceModuleColleAGauche = indiceModuleColleAGauche;
	}

	public void setIndiceModuleColleADroite(int indiceModuleColleADroite) {
		this.indiceModuleColleADroite = indiceModuleColleADroite;
	}

}

package vue;

import com.sun.javafx.tk.FontLoader;
import com.sun.javafx.tk.Toolkit;

import javafx.scene.Parent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class RectangleText extends Parent{

	private String leTexte = "";
	private double largeur = 0.0;
	private double hauteur = 0.0;
	private Font policeDuTexte =(new Font("Arial", 12));
	private double taillePolice = 12;
	private Color couleurDuTexte = Color.BLACK;
	private Color couleurDuFond = Color.LIGHTGRAY;
	private Color couleurDeLigne = Color.RED;
	
	public RectangleText(){
		
	}
	
	public RectangleText(String texte,Font police, Color ctxt, Color cfond, Color cligne){
		leTexte = texte;
		policeDuTexte = police;
		taillePolice = police.getSize();
		couleurDuTexte = ctxt;
		couleurDuFond = cfond;
		couleurDeLigne = cligne;

		FontLoader fontLoader = Toolkit.getToolkit().getFontLoader();
		float longueurTextPixels = fontLoader.computeStringWidth(leTexte, policeDuTexte);
		
		largeur = longueurTextPixels*1.1;
		hauteur = police.getSize()*1.2;
		Rectangle leFond = new Rectangle(largeur,hauteur);
		leFond.setStroke(cligne);
		leFond.setStrokeWidth(3);
		leFond.setFill(cfond);		
		this.getChildren().add(leFond);
		
		Text txtgraphic = new Text(texte);
		txtgraphic.setY(hauteur);
		txtgraphic.setX(largeur);
		txtgraphic.setFont(policeDuTexte);
		txtgraphic.setFill(ctxt);
		txtgraphic.setTranslateX(-longueurTextPixels*1.05);
		txtgraphic.setTranslateY(-police.getSize()*0.3);		
		this.getChildren().add(txtgraphic);
	}

	public String getLeTexte() {
		return leTexte;
	}

	public double getLargeur() {
		return largeur;
	}

	public double getHauteur() {
		return hauteur;
	}

	public Font getPoliceDuTexte() {
		return policeDuTexte;
	}

	public double getTaillePolice() {
		return policeDuTexte.getSize();
	}

	public Color getCouleurDuTexte() {
		return couleurDuTexte;
	}

	public Color getCouleurDuFond() {
		return couleurDuFond;
	}

	public Color getCouleurDeLigne() {
		return couleurDeLigne;
	}

	public void setLeTexte(String leTexte) {
		this.leTexte = leTexte;
	}

	public void setLargeur(double largeur) {
		this.largeur = largeur;
	}

	public void setHauteur(double hauteur) {
		this.hauteur = hauteur;
	}

	public void setPoliceDuTexte(Font policeDuTexte) {
		this.policeDuTexte = policeDuTexte;
	}

	public void setTaillePolice(int taillePolice) {
		this.taillePolice = taillePolice;
	}

	public void setCouleurDuTexte(Color couleurDuTexte) {
		this.couleurDuTexte = couleurDuTexte;
	}

	public void setCouleurDuFond(Color couleurDuFond) {
		this.couleurDuFond = couleurDuFond;
	}

	public void setCouleurDeLigne(Color couleurDeLigne) {
		this.couleurDeLigne = couleurDeLigne;
	}
}
